# Compte Rendu GBT — Guide de compilation APK

## 1. Installer les outils
1. Flutter SDK (≥ 3.22) : https://docs.flutter.dev/get-started/install/windows (ou macOS/Linux)
2. Android Studio (SDK Android + Command-line Tools) puis `flutter doctor --android-licenses`
3. `flutter doctor` doit être au vert pour « Android toolchain ».

## 2. Créer le projet et copier les fichiers
```
flutter create --org com.gbt --project-name compte_rendu_gbt --platforms android compte_rendu_gbt
cd compte_rendu_gbt
```
- Remplacer `pubspec.yaml` et `lib/main.dart` par ceux fournis.
- Remplacer `android/app/src/main/kotlin/com/gbt/compte_rendu_gbt/MainActivity.kt` par `android_patch/kotlin/MainActivity.kt`.
- Créer `android/app/src/main/res/xml/file_paths.xml` (copie de `android_patch/res_xml/file_paths.xml`).

## 3. Android : manifest et SDK
`android/app/src/main/AndroidManifest.xml` — avant `<application>` :
```xml
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.VIBRATE"/>
<uses-permission android:name="android.permission.USE_BIOMETRIC"/>
<uses-permission android:name="android.permission.READ_CONTACTS"/>
<uses-feature android:name="android.hardware.camera" android:required="false"/>
```
Dans `<application ...>` (à côté de `<activity>`) :
```xml
<provider android:name="androidx.core.content.FileProvider"
    android:authorities="${applicationId}.gbtprovider"
    android:exported="false" android:grantUriPermissions="true">
  <meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/file_paths"/>
</provider>
```
Ajouter aussi dans `<manifest>` : `<queries><package android:name="com.whatsapp"/></queries>`

`android/app/build.gradle(.kts)` → `defaultConfig { minSdk = 23 }`

## 4. Compiler
```
flutter pub get
flutter run                 # test sur téléphone (mode développeur + USB)
flutter build apk --release # génère l'APK
```
APK : `build/app/outputs/flutter-apk/app-release.apk` → copier sur le téléphone et installer (autoriser « sources inconnues »).

## Notes
- WhatsApp : le PDF est envoyé directement au contact choisi (indicatif par défaut 33 pour les numéros commençant par 0 ; modifier `norm()` si besoin). Si WhatsApp n'est pas installé, le menu de partage Android s'ouvre.
- Si erreur `local_auth` : vérifier que `MainActivity` hérite bien de `FlutterFragmentActivity` (déjà le cas).

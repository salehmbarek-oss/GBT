package com.gbt.compte_rendu_gbt

import android.content.Intent
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterFragmentActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "gbt/whatsapp")
            .setMethodCallHandler { call, result ->
                if (call.method == "send") {
                    try {
                        val path = call.argument<String>("path")!!
                        val phone = call.argument<String>("phone")
                        val uri = FileProvider.getUriForFile(this, "$packageName.gbtprovider", File(path))
                        val i = Intent(Intent.ACTION_SEND).apply {
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            if (!phone.isNullOrEmpty()) putExtra("jid", "$phone@s.whatsapp.net")
                            setPackage("com.whatsapp")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(i)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("ERR", e.message, null)
                    }
                } else result.notImplemented()
            }
    }
}

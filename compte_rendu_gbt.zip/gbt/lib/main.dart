import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart' as mlk;
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:local_auth/local_auth.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vibration/vibration.dart';

bool gLight = false;
Color kBg = Color(0xFF121212), kCard = Color(0xFF2C2C2C), kBar = Color(0xFF181818);
Color kCyan = Color(0xFF00E5FF), kGreen = Color(0xFF00E676);
Color kText = Colors.white, kDim = Colors.white60, kFaint = Colors.white38, kLine = Colors.white24;
final ValueNotifier<String> themeMode = ValueNotifier<String>('dark');
bool resolveLight(String m) => m == 'light' || (m == 'auto' && WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.light);
void setPalette(bool l) {
  gLight = l;
  kBg = l ? Colors.white : Color(0xFF121212);
  kCard = l ? Color(0xFFEEF2F6) : Color(0xFF2C2C2C);
  kBar = l ? Color(0xFFF6F8FA) : Color(0xFF181818);
  kCyan = l ? Color(0xFF00ACC1) : Color(0xFF00E5FF);
  kGreen = l ? Color(0xFF00C853) : Color(0xFF00E676);
  kText = l ? Color(0xFF111111) : Colors.white;
  kDim = l ? Colors.black54 : Colors.white60;
  kFaint = l ? Colors.black38 : Colors.white38;
  kLine = l ? Colors.black26 : Colors.white24;
}
const kActs = ['PTG', 'PTH', 'PTE', 'RACHIS', 'CLOUS GAMMA', 'CLOUS HUMERUS', 'PLAQUE', 'AUTRE'];
const _wa = MethodChannel('gbt/whatsapp');

// ───────────── Modèles ─────────────
class Item {
  String ref, lot, exp;
  int qty;
  Item({required this.ref, this.lot = '', this.qty = 1, this.exp = ''});
  Map<String, dynamic> toJson() => {'ref': ref, 'lot': lot, 'qty': qty, 'exp': exp};
  factory Item.fromJson(Map j) => Item(ref: j['ref'], lot: j['lot'], qty: j['qty'], exp: j['exp'] ?? '');
  bool get expired {
    final d = DateTime.tryParse(exp);
    return d != null && d.isBefore(DateTime.now());
  }
}

class Report {
  String date, patient = '', surgeon = '', facility = '', tech, act = '', complaint = '', sig = '';
  List<Item> items = [];
  List<String> photos = [];
  Report({required this.date, required this.tech});
  Map<String, dynamic> toJson() => {
        'date': date, 'patient': patient, 'surgeon': surgeon, 'facility': facility, 'tech': tech,
        'act': act, 'complaint': complaint, 'sig': sig, 'items': items.map((e) => e.toJson()).toList(), 'photos': photos
      };
  factory Report.fromJson(Map j) {
    final r = Report(date: j['date'], tech: j['tech']);
    r.patient = j['patient']; r.surgeon = j['surgeon']; r.facility = j['facility'];
    r.act = j['act']; r.complaint = j['complaint']; r.sig = j['sig'] ?? '';
    r.items = (j['items'] as List).map((e) => Item.fromJson(e)).toList();
    r.photos = List<String>.from(j['photos']);
    return r;
  }
}

String today() => DateFormat('yyyy-MM-dd').format(DateTime.now());

// ───────────── Stockage ─────────────
class Store {
  static const sec = FlutterSecureStorage();
  static late SharedPreferences p;
  static Future<void> init() async => p = await SharedPreferences.getInstance();
  static Future<String?> get pin => sec.read(key: 'pin');
  static Future<String?> get tech => sec.read(key: 'tech');
  static Future<String> get apiKey async => (await sec.read(key: 'apikey')) ?? '';
  static Future<void> setApiKey(String v) => v.isEmpty ? sec.delete(key: 'apikey') : sec.write(key: 'apikey', value: v);
  static Future<void> saveAuth(String pin, String tech) async {
    await sec.write(key: 'pin', value: pin);
    await sec.write(key: 'tech', value: tech);
  }
  static void saveDraft(Report r) => p.setString('draft', jsonEncode(r.toJson()));
  static Report? loadDraft() {
    final s = p.getString('draft');
    if (s == null) return null;
    try { return Report.fromJson(jsonDecode(s)); } catch (_) { return null; }
  }
  static void clearDraft() => p.remove('draft');
  static List<Map<String, dynamic>> get history =>
      (p.getStringList('history') ?? []).map((e) => Map<String, dynamic>.from(jsonDecode(e))).toList();
  static void addHistory(Map<String, dynamic> m) {
    final l = history..removeWhere((e) => e['file'] == m['file']);
    l.insert(0, m);
    p.setStringList('history', l.take(100).map(jsonEncode).toList());
  }
  static void delHistory(String file) {
    final l = history..removeWhere((e) => e['file'] == file);
    p.setStringList('history', l.map(jsonEncode).toList());
  }
  static String get logoPath => p.getString('logo') ?? '';
  static void setLogo(String v) => p.setString('logo', v);
  static List<String> hist(String k) => p.getStringList('h_$k') ?? [];
  static void addHist(String k, String v) {
    if (v.trim().isEmpty) return;
    final l = hist(k)..remove(v.trim())..insert(0, v.trim());
    p.setStringList('h_$k', l.take(50).toList());
  }
  static List<Map<String, String>> get favs =>
      (p.getStringList('favs') ?? []).map((e) => Map<String, String>.from(jsonDecode(e))).toList();
  static void addFav(Map<String, String> c) {
    final l = favs..removeWhere((e) => e['phone'] == c['phone']);
    l.insert(0, c);
    p.setStringList('favs', l.take(15).map(jsonEncode).toList());
  }
  static void delFav(String phone) {
    final l = favs..removeWhere((e) => e['phone'] == phone);
    p.setStringList('favs', l.map(jsonEncode).toList());
  }
}

// ───────────── Parser GS1-128 / DataMatrix ─────────────
Item parseGs1(String raw) {
  var s = raw.replaceAll(RegExp(r'^\](d2|C1|Q3|d1)'), '');
  final it = Item(ref: '');
  void apply(String ai, String v) {
    if (ai == '01') it.ref = v;
    if (ai == '10') it.lot = v;
    if (ai == '17' && v.length == 6) {
      final dd = v.substring(4) == '00' ? '28' : v.substring(4);
      it.exp = '20${v.substring(0, 2)}-${v.substring(2, 4)}-$dd';
    }
  }
  if (s.contains('(')) {
    for (final m in RegExp(r'\((\d{2,4})\)([^(]*)').allMatches(s)) apply(m.group(1)!, m.group(2)!);
  } else {
    var i = 0;
    const fixed = {'01': 14, '00': 18, '11': 6, '13': 6, '15': 6, '17': 6};
    while (i + 2 <= s.length) {
      if (s[i] == '\x1d') { i++; continue; }
      final ai = s.substring(i, i + 2);
      int len;
      if (fixed.containsKey(ai)) {
        len = min(fixed[ai]!, s.length - i - 2);
        apply(ai, s.substring(i + 2, i + 2 + len));
        i += 2 + len;
      } else if (ai == '10' || ai == '21' || ai.startsWith('9')) {
        var e = s.indexOf('\x1d', i + 2);
        if (e < 0) {
          e = s.length;
          if (ai == '10') {
            final mm = RegExp(r'^(.+?)17(\d{2})(0[1-9]|1[0-2])(\d{2})$').firstMatch(s.substring(i + 2));
            final yy = mm == null ? 0 : int.parse(mm.group(2)!);
            if (mm != null && yy >= 24 && yy <= 45) {
              apply('10', mm.group(1)!);
              apply('17', s.substring(s.length - 6));
              i = s.length;
              continue;
            }
          }
        }
        apply(ai, s.substring(i + 2, e));
        i = e;
      } else { break; }
    }
  }
  if (it.ref.isEmpty && it.lot.isEmpty) it.ref = raw.trim();
  return it;
}

// ───────────── PDF (fond blanc) ─────────────
Future<Uint8List> buildPdf(Report r) async {
  final doc = pw.Document();
  final appLogo = pw.MemoryImage((await rootBundle.load('assets/logo.png')).buffer.asUint8List());
  pw.MemoryImage? custom;
  final lp = Store.logoPath;
  if (lp.isNotEmpty && File(lp).existsSync()) custom = pw.MemoryImage(File(lp).readAsBytesSync());
  pw.MemoryImage? sig;
  if (r.sig.isNotEmpty) sig = pw.MemoryImage(base64Decode(r.sig));
  const blue = PdfColor.fromInt(0xFF0277BD);
  pw.Widget h(String t) => pw.Container(
      margin: pw.EdgeInsets.only(top: 16, bottom: 6),
      padding: pw.EdgeInsets.only(bottom: 3),
      decoration: pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(color: blue, width: 1.5))),
      child: pw.Text(t, style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: blue)));
  pw.TableRow row(String a, String b) => pw.TableRow(children: [
        pw.Padding(padding: pw.EdgeInsets.all(5), child: pw.Text(a, style: pw.TextStyle(fontWeight: pw.FontWeight.bold))),
        pw.Padding(padding: pw.EdgeInsets.all(5), child: pw.Text(b)),
      ]);
  final photos = <pw.Widget>[];
  for (final p in r.photos) {
    final f = File(p);
    if (!f.existsSync()) continue;
    photos.add(pw.Container(
        width: 240, height: 180,
        decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey500)),
        child: pw.Image(pw.MemoryImage(f.readAsBytesSync()), fit: pw.BoxFit.contain)));
  }
  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: pw.EdgeInsets.all(32),
    theme: pw.ThemeData.withFont(base: pw.Font.helvetica(), bold: pw.Font.helveticaBold()),
    build: (c) => [
      pw.Container(
          color: blue, padding: pw.EdgeInsets.all(12),
          child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
            pw.Row(children: [
              pw.Container(width: 38, height: 38, child: pw.Image(appLogo)),
              pw.SizedBox(width: 10),
              pw.Text('Compte Rendu GBT', style: pw.TextStyle(fontSize: 21, color: PdfColors.white, fontWeight: pw.FontWeight.bold)),
            ]),
            pw.Row(children: [
              if (custom != null) pw.Container(height: 38, child: pw.Image(custom)),
              if (custom != null) pw.SizedBox(width: 10),
              pw.Text(r.date, style: pw.TextStyle(fontSize: 14, color: PdfColors.white)),
            ]),
          ])),
      h('Informations générales'),
      pw.Table(border: pw.TableBorder.all(color: PdfColors.grey400), columnWidths: {0: pw.FixedColumnWidth(120)}, children: [
        row('Date', r.date), row('Patient', r.patient), row('Chirurgien', r.surgeon),
        row('Établissement', r.facility), row('Technicien', r.tech), row('Acte chirurgical', r.act),
      ]),
      h('Consommables'),
      r.items.isEmpty
          ? pw.Text('Aucun consommable.')
          : pw.TableHelper.fromTextArray(
              headers: ['Référence', 'N° de lot', 'Péremption', 'Qté'],
              data: r.items.map((e) => [e.ref, e.lot, e.exp, '${e.qty}']).toList(),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white),
              headerDecoration: pw.BoxDecoration(color: blue),
              cellStyle: pw.TextStyle(fontSize: 10),
              border: pw.TableBorder.all(color: PdfColors.grey400),
              cellAlignments: {3: pw.Alignment.center}),
      if (sig != null) ...[
        h('Signature du technicien'),
        pw.Container(height: 64, alignment: pw.Alignment.centerLeft, child: pw.Image(sig, height: 60)),
      ],
      if (r.complaint.trim().isNotEmpty || photos.isNotEmpty) ...[
        pw.NewPage(),
        h('Réclamation / Remarques'),
        pw.Text(r.complaint.isEmpty ? '—' : r.complaint),
        pw.SizedBox(height: 12),
        pw.Wrap(spacing: 10, runSpacing: 10, children: photos),
      ],
    ],
  ));
  return doc.save();
}

// ───────────── Hexagone / identité visuelle ─────────────
Path _hex(Size s) {
  final c = Offset(s.width / 2, s.height / 2);
  final r = min(s.width, s.height) / 2;
  final p = Path();
  for (var i = 0; i < 6; i++) {
    final a = pi / 180 * (60 * i - 90);
    final pt = Offset(c.dx + r * cos(a), c.dy + r * sin(a));
    i == 0 ? p.moveTo(pt.dx, pt.dy) : p.lineTo(pt.dx, pt.dy);
  }
  return p..close();
}

class HexPainter extends CustomPainter {
  final Color fill, stroke;
  final double sw;
  HexPainter(this.fill, this.stroke, this.sw);
  @override
  void paint(Canvas c, Size s) {
    final p = _hex(Size(s.width - sw, s.height - sw)).shift(Offset(sw / 2, sw / 2));
    c.drawPath(p, Paint()..color = fill);
    if (sw > 0) {
      c.drawPath(p, Paint()..color = stroke..style = PaintingStyle.stroke..strokeWidth = sw..strokeJoin = StrokeJoin.round);
    }
  }
  @override
  bool shouldRepaint(HexPainter o) => o.fill != fill || o.stroke != stroke || o.sw != sw;
}

class HexBadge extends StatelessWidget {
  final double size, sw;
  final Color? fill, stroke;
  final Widget? child;
  HexBadge({super.key, required this.size, this.fill, this.stroke, this.sw = 2, this.child});
  @override
  Widget build(BuildContext c) => SizedBox(width: size, height: size, child: CustomPaint(painter: HexPainter(fill ?? kCard, stroke ?? kCyan, sw), child: Center(child: child)));
}

Widget gbtLogo(double size) => Image.asset('assets/logo.png', width: size, height: size);

Widget sec(IconData i, String t) => Padding(
    padding: EdgeInsets.only(top: 4, bottom: 12),
    child: Row(children: [
      Icon(i, size: 18, color: kCyan),
      SizedBox(width: 8),
      Text(t, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, letterSpacing: 0.3)),
    ]));

// ───────────── App ─────────────
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.init();
  themeMode.value = Store.p.getString('theme') ?? 'dark';
  runApp(App());
}

class App extends StatelessWidget {
  App({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
        valueListenable: themeMode,
        builder: (ctx, m, _) {
          setPalette(resolveLight(m));
          return MaterialApp(title: 'Compte Rendu GBT', debugShowCheckedModeBanner: false, theme: buildTheme(), home: Gate());
        });
}

ThemeData buildTheme() {
  final l = gLight;
  OutlineInputBorder ob(Color c, double w) => OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: c, width: w));
  return ThemeData(
    useMaterial3: true,
    brightness: l ? Brightness.light : Brightness.dark,
    scaffoldBackgroundColor: kBg,
    cardColor: kCard,
    colorScheme: l ? ColorScheme.light(primary: kCyan, secondary: kGreen, surface: kCard) : ColorScheme.dark(primary: kCyan, secondary: kGreen, surface: kCard),
    appBarTheme: AppBarTheme(backgroundColor: kBg, foregroundColor: kText, elevation: 0, scrolledUnderElevation: 0),
    inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: kCard,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        focusedBorder: ob(kCyan, 1.5), errorBorder: ob(Colors.redAccent, 1), focusedErrorBorder: ob(Colors.redAccent, 1.5)),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(minimumSize: Size(0, 56), foregroundColor: Colors.black, textStyle: TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(minimumSize: Size(0, 56), foregroundColor: kText, side: BorderSide(color: kLine))),
  );
}

class Gate extends StatefulWidget {
  Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  bool? hasPin;
  @override
  void initState() {
    super.initState();
    Store.pin.then((p) => setState(() => hasPin = p != null));
  }
  @override
  Widget build(BuildContext c) {
    if (hasPin == null) return Scaffold(body: Center(child: CircularProgressIndicator()));
    return hasPin! ? LockPage() : SetupPage();
  }
}

class PinPad extends StatefulWidget {
  final int length;
  final String title;
  final ValueChanged<String> onDone;
  final Widget? extra;
  PinPad({super.key, required this.length, required this.title, required this.onDone, this.extra});
  @override
  State<PinPad> createState() => _PinPadState();
}

class _PinPadState extends State<PinPad> {
  String v = '';
  void tap(String d) {
    HapticFeedback.lightImpact();
    if (d == '<') { if (v.isNotEmpty) setState(() => v = v.substring(0, v.length - 1)); return; }
    if (v.length >= widget.length) return;
    setState(() => v += d);
    if (v.length == widget.length) {
      final x = v;
      Future.delayed(Duration(milliseconds: 150), () { if (mounted) setState(() => v = ''); widget.onDone(x); });
    }
  }
  @override
  Widget build(BuildContext c) {
    Widget key(String k) => Expanded(
        child: Padding(
            padding: EdgeInsets.all(6),
            child: k.isEmpty
                ? SizedBox(height: 68)
                : FilledButton.tonal(
                    style: FilledButton.styleFrom(minimumSize: Size(0, 68), foregroundColor: kText),
                    onPressed: () => tap(k),
                    child: k == '<' ? Icon(Icons.backspace_outlined) : Text(k, style: TextStyle(fontSize: 26)))));
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Text(widget.title, style: TextStyle(fontSize: 18)),
      SizedBox(height: 14),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        for (var i = 0; i < widget.length; i++)
          Container(margin: EdgeInsets.all(6), width: 16, height: 16,
              decoration: BoxDecoration(shape: BoxShape.circle, color: i < v.length ? kCyan : kLine))
      ]),
      if (widget.extra != null) widget.extra!,
      SizedBox(height: 16),
      for (final r in [['1', '2', '3'], ['4', '5', '6'], ['7', '8', '9'], ['', '0', '<']]) Row(children: r.map(key).toList()),
    ]);
  }
}

class SetupPage extends StatefulWidget {
  SetupPage({super.key});
  @override
  State<SetupPage> createState() => _SetupPageState();
}

class _SetupPageState extends State<SetupPage> {
  final name = TextEditingController();
  int len = 4;
  String? first;
  @override
  Widget build(BuildContext c) => Scaffold(
        body: SafeArea(
            child: SingleChildScrollView(
                padding: EdgeInsets.all(20),
                child: Column(children: [
                  SizedBox(height: 10),
                  gbtLogo(84),
                  Text('Compte Rendu GBT', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                  SizedBox(height: 20),
                  if (first == null) ...[
                    TextField(controller: name, decoration: InputDecoration(labelText: 'Nom du technicien')),
                    SizedBox(height: 12),
                    SegmentedButton<int>(
                        segments: [ButtonSegment(value: 4, label: Text('PIN 4 chiffres')), ButtonSegment(value: 6, label: Text('PIN 6 chiffres'))],
                        selected: {len}, onSelectionChanged: (s) => setState(() => len = s.first)),
                    SizedBox(height: 20),
                  ],
                  PinPad(
                      key: ValueKey('$len$first'), length: len,
                      title: first == null ? 'Créez votre code PIN' : 'Confirmez le code PIN',
                      onDone: (p) async {
                        if (name.text.trim().isEmpty) {
                          ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('Saisissez le nom du technicien')));
                          return;
                        }
                        if (first == null) { setState(() => first = p); return; }
                        if (first != p) {
                          setState(() => first = null);
                          ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('Les codes ne correspondent pas')));
                          return;
                        }
                        await Store.saveAuth(p, name.text.trim());
                        if (c.mounted) Navigator.pushReplacement(c, MaterialPageRoute(builder: (_) => Wizard()));
                      }),
                ]))),
      );
}

class LockPage extends StatefulWidget {
  LockPage({super.key});
  @override
  State<LockPage> createState() => _LockPageState();
}

class _LockPageState extends State<LockPage> {
  String? pin;
  final auth = LocalAuthentication();
  @override
  void initState() {
    super.initState();
    Store.pin.then((p) => setState(() => pin = p));
    WidgetsBinding.instance.addPostFrameCallback((_) => bio());
  }
  void open() => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => Wizard()));
  Future<void> bio() async {
    try {
      if (await auth.canCheckBiometrics &&
          await auth.authenticate(localizedReason: 'Déverrouiller Compte Rendu GBT', options: AuthenticationOptions(biometricOnly: true))) {
        if (mounted) open();
      }
    } catch (_) {}
  }
  @override
  Widget build(BuildContext c) => Scaffold(
        body: SafeArea(
            child: Center(
                child: pin == null
                    ? CircularProgressIndicator()
                    : SingleChildScrollView(
                        padding: EdgeInsets.all(20),
                        child: Column(mainAxisSize: MainAxisSize.min, children: [
                          gbtLogo(84),
                          SizedBox(height: 10),
                          PinPad(
                              length: pin!.length, title: 'Entrez votre code PIN',
                              onDone: (p) {
                                if (p == pin) { open(); } else {
                                  HapticFeedback.heavyImpact();
                                  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('Code incorrect')));
                                }
                              }),
                          TextButton.icon(onPressed: bio, icon: Icon(Icons.fingerprint), label: Text('Biométrie')),
                        ])))),
      );
}

// ───────────── Assistant 4 étapes ─────────────
class AutoField extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final String? error;
  final List<String> options;
  final ValueChanged<String> onChanged;
  AutoField({super.key, required this.label, required this.value, required this.icon, required this.options, required this.onChanged, this.error});
  @override
  Widget build(BuildContext c) => Autocomplete<String>(
        initialValue: TextEditingValue(text: value),
        optionsBuilder: (v) => v.text.isEmpty ? <String>[] : options.where((o) => o.toLowerCase().contains(v.text.toLowerCase())),
        onSelected: onChanged,
        fieldViewBuilder: (ctx, ctrl, fn, _) => TextField(
            controller: ctrl, focusNode: fn, onChanged: onChanged,
            decoration: InputDecoration(labelText: '$label *', prefixIcon: Icon(icon, color: kDim), errorText: error)),
      );
}

class Wizard extends StatefulWidget {
  Wizard({super.key});
  @override
  State<Wizard> createState() => _WizardState();
}

class _WizardState extends State<Wizard> {
  Report? r;
  int step = 0, ver = 0;
  bool showErr = false;
  final steps = ['Info', 'Consommables', 'Réclamation', 'Envoi'];

  @override
  void initState() {
    super.initState();
    () async {
      final t = await Store.tech ?? '';
      setState(() => r = Store.loadDraft() ?? Report(date: today(), tech: t));
    }();
  }

  void chg() { setState(() {}); Store.saveDraft(r!); }
  void snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  bool get infoOk =>
      r!.date.isNotEmpty && r!.patient.trim().isNotEmpty && r!.surgeon.trim().isNotEmpty &&
      r!.facility.trim().isNotEmpty && r!.tech.trim().isNotEmpty && r!.act.isNotEmpty;

  void goTo(int n) {
    if (n > 0 && !infoOk) {
      HapticFeedback.heavyImpact();
      setState(() { showErr = true; step = 0; });
      snack('Remplissez tous les champs obligatoires (*) pour continuer');
      return;
    }
    if (n >= 3 && r!.items.isEmpty) {
      HapticFeedback.heavyImpact();
      setState(() => step = 1);
      snack('Ajoutez au moins un consommable avant la validation');
      return;
    }
    HapticFeedback.selectionClick();
    setState(() => step = n);
  }

  // ── Stepper hexagonal ──
  Widget node(int i) {
    final done = i < step, act = i == step;
    return SizedBox(
        width: 66,
        child: InkWell(
            onTap: () => goTo(i),
            child: Column(children: [
              HexBadge(
                  size: 36, sw: act ? 0 : 1.5,
                  fill: done ? kGreen : act ? kCyan : kCard, stroke: kLine,
                  child: done ? Icon(Icons.check, size: 18, color: Colors.black) : Text('${i + 1}', style: TextStyle(fontWeight: FontWeight.bold, color: act ? Colors.black : kDim))),
              SizedBox(height: 4),
              Text(steps[i], maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, fontWeight: act ? FontWeight.bold : FontWeight.normal, color: act ? kCyan : kDim)),
            ])));
  }

  Widget stepper() {
    final items = <Widget>[];
    for (var i = 0; i < 4; i++) {
      items.add(node(i));
      if (i < 3) items.add(Expanded(child: Padding(padding: EdgeInsets.only(top: 17), child: Container(height: 2, color: i < step ? kGreen : kLine))));
    }
    return Container(
        color: kBar,
        padding: EdgeInsets.fromLTRB(10, 12, 10, 10),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: items));
  }

  // ── ÉTAPE 1 ──
  Widget s1() {
    final rr = r!;
    String? e(String v) => showErr && v.trim().isEmpty ? 'Champ obligatoire' : null;
    InputDecoration d(String l, IconData i, String v) => InputDecoration(labelText: '$l *', prefixIcon: Icon(i, color: kDim), errorText: e(v));
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      sec(Icons.assignment_outlined, 'Informations générales'),
      InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () async {
            final dt = await showDatePicker(context: context, initialDate: DateTime.tryParse(rr.date) ?? DateTime.now(), firstDate: DateTime(2020), lastDate: DateTime(2100));
            if (dt != null) { rr.date = DateFormat('yyyy-MM-dd').format(dt); chg(); }
          },
          child: Container(
              padding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(14)),
              child: Row(children: [
                Icon(Icons.calendar_today, color: kCyan),
                SizedBox(width: 12),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text("Date de l'opération *", style: TextStyle(fontSize: 12, color: kDim)),
                  Text(rr.date, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                ]),
                Spacer(),
                Icon(Icons.edit, size: 18, color: kFaint),
              ]))),
      SizedBox(height: 14),
      TextFormField(key: ValueKey('p$ver'), initialValue: rr.patient, textCapitalization: TextCapitalization.words, decoration: d('Nom du patient', Icons.person_outline, rr.patient), onChanged: (v) { rr.patient = v; chg(); }),
      SizedBox(height: 14),
      AutoField(key: ValueKey('s$ver'), label: 'Chirurgien', icon: Icons.medical_services_outlined, value: rr.surgeon, options: Store.hist('surgeon'), error: e(rr.surgeon), onChanged: (v) { rr.surgeon = v; chg(); }),
      SizedBox(height: 14),
      AutoField(key: ValueKey('f$ver'), label: 'Établissement', icon: Icons.local_hospital_outlined, value: rr.facility, options: Store.hist('facility'), error: e(rr.facility), onChanged: (v) { rr.facility = v; chg(); }),
      SizedBox(height: 14),
      TextFormField(key: ValueKey('t$ver'), initialValue: rr.tech, textCapitalization: TextCapitalization.words, decoration: d('Technicien', Icons.badge_outlined, rr.tech), onChanged: (v) { rr.tech = v; chg(); }),
      SizedBox(height: 20),
      sec(Icons.healing, 'Acte chirurgical *'),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final a in kActs)
          ChoiceChip(
              showCheckmark: false,
              label: Padding(padding: EdgeInsets.symmetric(horizontal: 6, vertical: 10), child: Text(a, style: TextStyle(fontWeight: FontWeight.bold, color: rr.act == a ? Colors.black : kText))),
              selected: rr.act == a, selectedColor: kCyan, backgroundColor: kCard,
              shape: StadiumBorder(side: BorderSide(color: showErr && rr.act.isEmpty ? Colors.redAccent : Colors.transparent)),
              onSelected: (_) { HapticFeedback.selectionClick(); rr.act = a; chg(); })
      ]),
      if (showErr && rr.act.isEmpty) Padding(padding: EdgeInsets.only(top: 6, left: 4), child: Text('Choisissez un acte chirurgical', style: TextStyle(color: Colors.redAccent, fontSize: 12))),
      SizedBox(height: 10),
      Text('* Tous les champs sont obligatoires pour passer aux consommables.', style: TextStyle(fontSize: 11, color: kFaint)),
    ]);
  }

  // ── ÉTAPE 2 ──
  Future<void> editItem([Item? it]) async {
    final ref = TextEditingController(text: it?.ref), lot = TextEditingController(text: it?.lot);
    final qty = TextEditingController(text: '${it?.qty ?? 1}');
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
              title: Text(it == null ? 'Ajouter un article' : 'Modifier'),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(controller: ref, decoration: InputDecoration(labelText: 'Référence')),
                SizedBox(height: 10),
                TextField(controller: lot, decoration: InputDecoration(labelText: 'Numéro de lot')),
                SizedBox(height: 10),
                TextField(controller: qty, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Quantité')),
              ]),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: Text('Annuler')),
                FilledButton(onPressed: () => Navigator.pop(context, true), child: Text('OK')),
              ],
            ));
    if (ok != true || ref.text.trim().isEmpty) return;
    final q = max(1, int.tryParse(qty.text) ?? 1);
    if (it == null) {
      final dup = r!.items.where((e) => e.ref == ref.text.trim() && e.lot == lot.text.trim());
      if (dup.isNotEmpty) { dup.first.qty += q; snack('Doublon : quantité +$q'); } else { r!.items.add(Item(ref: ref.text.trim(), lot: lot.text.trim(), qty: q)); }
    } else { it.ref = ref.text.trim(); it.lot = lot.text.trim(); it.qty = q; }
    chg();
  }

  Widget altBtn(IconData i, String t, VoidCallback f) => Expanded(
      child: OutlinedButton(
          style: OutlinedButton.styleFrom(minimumSize: Size(0, 64), padding: EdgeInsets.symmetric(horizontal: 4)),
          onPressed: f,
          child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(i, size: 22), SizedBox(height: 4), Text(t, style: TextStyle(fontSize: 12))])));

  Future<void> photoCapture([ImageSource src = ImageSource.camera]) async {
    final x = await ImagePicker().pickImage(source: src, imageQuality: 90, maxWidth: 2200);
    if (x == null || !mounted) return;
    final res = await Navigator.push<Item>(context, MaterialPageRoute(builder: (_) => PhotoResultPage(path: x.path)));
    if (res == null) return;
    final dup = r!.items.where((e) => e.ref == res.ref && e.lot == res.lot);
    if (dup.isNotEmpty) {
      HapticFeedback.heavyImpact();
      dup.first.qty += 1;
      snack('Doublon : quantité +1');
    } else {
      HapticFeedback.mediumImpact();
      r!.items.add(res);
      snack('Article ajouté');
    }
    chg();
  }

  Widget qtyBtn(IconData i, VoidCallback f) => InkWell(onTap: f, customBorder: CircleBorder(), child: Padding(padding: EdgeInsets.all(6), child: Icon(i, color: kCyan, size: 28)));

  Widget s2() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        sec(Icons.inventory_2_outlined, 'Consommables'),
        FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: kCyan, minimumSize: Size(double.infinity, 64)),
            onPressed: () => photoCapture(),
            icon: Icon(Icons.photo_camera, size: 28),
            label: Text("PHOTO DE L'ÉTIQUETTE")),
        SizedBox(height: 10),
        Row(children: [
          altBtn(Icons.photo_library_outlined, 'Galerie', () => photoCapture(ImageSource.gallery)),
          SizedBox(width: 8),
          altBtn(Icons.qr_code_scanner, 'Code-barres', () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => ScanPage(r: r!)));
            chg();
          }),
          SizedBox(width: 8),
          altBtn(Icons.edit_note, 'Manuel', () => editItem()),
        ]),
        SizedBox(height: 16),
        if (r!.items.isEmpty)
          Container(
              width: double.infinity, padding: EdgeInsets.all(28),
              decoration: BoxDecoration(border: Border.all(color: kLine), borderRadius: BorderRadius.circular(16)),
              child: Column(children: [Icon(Icons.qr_code_2, size: 44, color: kLine), SizedBox(height: 8), Text("Photographiez l'étiquette de votre premier article", style: TextStyle(color: kDim))])),
        for (final it in r!.items)
          Padding(
              padding: EdgeInsets.only(bottom: 10),
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                      color: kCard,
                      child: IntrinsicHeight(
                          child: Row(children: [
                        Container(width: 5, color: it.expired ? Colors.redAccent : kCyan),
                        Expanded(
                            child: Padding(
                                padding: EdgeInsets.fromLTRB(12, 10, 4, 10),
                                child: Row(children: [
                                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                    Text('Réf : ${it.ref}', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                    SizedBox(height: 2),
                                    Text('Lot : ${it.lot.isEmpty ? "—" : it.lot}', style: TextStyle(color: kDim)),
                                    if (it.exp.isNotEmpty) Text('Péremption : ${it.exp}${it.expired ? "  ⚠ PÉRIMÉ" : ""}', style: TextStyle(fontSize: 12, color: it.expired ? Colors.redAccent : kDim)),
                                  ])),
                                  qtyBtn(Icons.remove_circle_outline, () { if (it.qty > 1) { it.qty--; chg(); } }),
                                  Text('${it.qty}', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                                  qtyBtn(Icons.add_circle_outline, () { it.qty++; chg(); }),
                                  PopupMenuButton<String>(
                                      onSelected: (v) { if (v == 'e') { editItem(it); } else { r!.items.remove(it); chg(); } },
                                      itemBuilder: (_) => [PopupMenuItem(value: 'e', child: Text('Modifier')), PopupMenuItem(value: 'd', child: Text('Supprimer'))]),
                                ]))),
                      ]))))),
      ]);

  // ── ÉTAPE 3 ──
  Future<void> addPhoto(ImageSource s) async {
    final ps = s == ImageSource.camera
        ? [await ImagePicker().pickImage(source: s, imageQuality: 70, maxWidth: 1280)]
        : await ImagePicker().pickMultiImage(imageQuality: 70, maxWidth: 1280);
    for (final p in ps) { if (p != null) r!.photos.add(p.path); }
    chg();
  }

  Widget s3() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        sec(Icons.report_problem_outlined, 'Réclamation / Remarques'),
        Text('Optionnel : incident, emballage endommagé, produit défectueux…', style: TextStyle(color: kDim, fontSize: 12)),
        SizedBox(height: 12),
        TextFormField(key: ValueKey('c$ver'), initialValue: r!.complaint, maxLines: 6, decoration: InputDecoration(labelText: 'Description'), onChanged: (v) { r!.complaint = v; Store.saveDraft(r!); }),
        SizedBox(height: 12),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: () => addPhoto(ImageSource.camera), icon: Icon(Icons.photo_camera_outlined), label: Text('Photo'))),
          SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(onPressed: () => addPhoto(ImageSource.gallery), icon: Icon(Icons.photo_library_outlined), label: Text('Galerie'))),
        ]),
        SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final p in r!.photos)
            Stack(children: [
              ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(p), width: 100, height: 100, fit: BoxFit.cover)),
              Positioned(right: 2, top: 2, child: InkWell(onTap: () { r!.photos.remove(p); chg(); }, child: CircleAvatar(radius: 13, backgroundColor: Colors.red, child: Icon(Icons.close, size: 16)))),
            ])
        ]),
      ]);

  // ── ÉTAPE 4 ──
  String fname() => 'CompteRendu_${r!.date}_${r!.tech.trim().replaceAll(RegExp(r'\s+'), '_')}.pdf';

  Widget row(String a, String b) => Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 110, child: Text(a, style: TextStyle(color: kDim, fontSize: 13))),
        Expanded(child: Text(b.isEmpty ? '—' : b, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500))),
      ]));

  Widget s4() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        sec(Icons.fact_check_outlined, 'Validation'),
        Container(
            width: double.infinity, padding: EdgeInsets.all(16),
            decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(16)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(Icons.picture_as_pdf, color: kCyan, size: 20), SizedBox(width: 8), Expanded(child: Text(fname(), style: TextStyle(color: kCyan, fontWeight: FontWeight.bold, fontSize: 12)))]),
              Divider(height: 22),
              row('Date', r!.date), row('Patient', r!.patient), row('Chirurgien', r!.surgeon),
              row('Établissement', r!.facility), row('Technicien', r!.tech), row('Acte', r!.act),
              Divider(height: 22),
              Row(children: [
                Chip(avatar: Icon(Icons.inventory_2_outlined, size: 16), label: Text('${r!.items.length} article(s)')),
                SizedBox(width: 8),
                Chip(avatar: Icon(Icons.photo_outlined, size: 16), label: Text('${r!.photos.length} photo(s)')),
              ]),
            ])),
        SizedBox(height: 18),
        sec(Icons.draw_outlined, 'Signature du technicien'),
        SignaturePad(key: ValueKey('g$ver'), value: r!.sig, onChanged: (b) { r!.sig = b; chg(); }),
        SizedBox(height: 16),
        OutlinedButton.icon(
            icon: Icon(Icons.visibility_outlined), label: Text('Aperçu PDF (fond blanc)'),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(
                appBar: AppBar(title: Text('Aperçu')),
                body: PdfPreview(build: (_) => buildPdf(r!), canChangeOrientation: false, canChangePageFormat: false, canDebug: false, allowPrinting: false, allowSharing: false, pdfFileName: fname()))))),
        SizedBox(height: 12),
        FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: kGreen, minimumSize: Size(0, 60)), icon: Icon(Icons.send), label: Text('Valider & Envoyer via WhatsApp'), onPressed: send),
      ]);

  Future<void> send() async {
    if (!infoOk) { goTo(1); return; }
    if (r!.items.isEmpty) { goTo(3); return; }
    final rec = await Navigator.push<Map<String, String>>(context, MaterialPageRoute(builder: (_) => RecipientPage()));
    if (rec == null) return;
    Store.addHist('surgeon', r!.surgeon);
    Store.addHist('facility', r!.facility);
    final bytes = await buildPdf(r!);
    final dir = await getApplicationDocumentsDirectory();
    final f = File('${dir.path}/${fname()}');
    await f.writeAsBytes(bytes);
    Store.addHistory({
      'file': f.path, 'name': fname(), 'date': r!.date, 'patient': r!.patient, 'surgeon': r!.surgeon,
      'facility': r!.facility, 'act': r!.act, 'items': r!.items.length, 'sentAt': DateTime.now().toIso8601String()
    });
    await sendPdf(f.path, rec['phone'] ?? '');
    snack('PDF enregistré et ajouté à l\'historique');
  }

  // ── Bouton Actualiser : nouveau formulaire vierge ──
  Future<void> reset() async {
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
              icon: Icon(Icons.refresh, color: kCyan, size: 32),
              title: Text('Actualiser le formulaire ?'),
              content: Text('Le compte rendu en cours sera effacé et un nouveau formulaire vierge sera créé.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: Text('Annuler')),
                FilledButton(onPressed: () => Navigator.pop(context, true), child: Text('Actualiser')),
              ],
            ));
    if (ok == true) {
      Store.clearDraft();
      setState(() { r = Report(date: today(), tech: r!.tech); step = 0; showErr = false; ver++; });
      snack('Nouveau compte rendu prêt');
    }
  }

  @override
  Widget build(BuildContext c) {
    if (r == null) return Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(
          titleSpacing: 12,
          title: Row(children: [gbtLogo(36), SizedBox(width: 8), Flexible(child: Text('Compte Rendu GBT', overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)))]),
          actions: [
            IconButton(tooltip: 'Historique', icon: Icon(Icons.history), onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => HistoryPage()))),
            IconButton(tooltip: 'Actualiser / nouveau compte rendu', icon: Icon(Icons.refresh, size: 26), onPressed: reset),
            IconButton(tooltip: 'Réglages', icon: Icon(Icons.tune), onPressed: () async {
              await Navigator.push(c, MaterialPageRoute(builder: (_) => SettingsPage()));
              if (mounted) setState(() {});
            }),
          ]),
      body: Column(children: [
        stepper(),
        Expanded(
            child: AnimatedSwitcher(
                duration: Duration(milliseconds: 220),
                child: SingleChildScrollView(key: ValueKey('$ver-$step'), padding: EdgeInsets.all(16), child: [s1, s2, s3, s4][step]()))),
        Container(
            decoration: BoxDecoration(color: kBar, border: Border(top: BorderSide(color: kLine))),
            padding: EdgeInsets.fromLTRB(12, 10, 12, 10),
            child: SafeArea(
                top: false,
                child: Row(children: [
                  if (step > 0) Expanded(child: OutlinedButton.icon(onPressed: () => goTo(step - 1), icon: Icon(Icons.arrow_back), label: Text('Retour'))),
                  if (step > 0 && step < 3) SizedBox(width: 10),
                  if (step < 3) Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: kCyan), onPressed: () => goTo(step + 1), icon: Icon(Icons.arrow_forward), label: Text('Suivant'))),
                ]))),
      ]),
    );
  }
}

// ───────────── Scanner ─────────────
class ScanPage extends StatefulWidget {
  final Report r;
  ScanPage({super.key, required this.r});
  @override
  State<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> {
  final c = MobileScannerController(
      detectionSpeed: DetectionSpeed.noDuplicates,
      formats: [BarcodeFormat.dataMatrix, BarcodeFormat.code128, BarcodeFormat.qrCode, BarcodeFormat.ean13, BarcodeFormat.code39]);
  bool torch = false;
  DateTime last = DateTime(2000);
  String msg = 'Visez un code-barres / DataMatrix';
  Color col = kCyan;

  Future<void> ok() async { if ((await Vibration.hasVibrator()) == true) Vibration.vibrate(duration: 80); }
  Future<void> ko() async {
    SystemSound.play(SystemSoundType.alert);
    if ((await Vibration.hasVibrator()) == true) Vibration.vibrate(pattern: [0, 120, 80, 120]);
  }

  void onDetect(BarcodeCapture cap) {
    final raw = cap.barcodes.firstOrNull?.rawValue;
    if (raw == null || DateTime.now().difference(last).inMilliseconds < 1200) return;
    last = DateTime.now();
    final it = parseGs1(raw);
    final dup = widget.r.items.where((e) => e.ref == it.ref && e.lot == it.lot);
    if (dup.isNotEmpty) {
      dup.first.qty++;
      ko();
      setState(() { msg = 'DOUBLON ${it.ref} → quantité ${dup.first.qty}'; col = Colors.orange; });
    } else if (it.expired) {
      widget.r.items.add(it);
      ko();
      setState(() { msg = '⚠ PÉRIMÉ (${it.exp}) : ${it.ref}'; col = Colors.redAccent; });
    } else {
      widget.r.items.add(it);
      ok();
      setState(() { msg = 'Ajouté : ${it.ref}  Lot ${it.lot}'; col = kGreen; });
    }
    Store.saveDraft(widget.r);
  }

  @override
  void dispose() { c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext ctx) => Scaffold(
        appBar: AppBar(title: Text('Scan (${widget.r.items.length})'), actions: [
          IconButton(icon: Icon(torch ? Icons.flash_on : Icons.flash_off, color: torch ? Colors.yellow : null, size: 30), onPressed: () async {
            try {
              await c.toggleTorch();
              setState(() => torch = !torch);
            } catch (_) {
              ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('Lampe torche indisponible sur cet appareil')));
            }
          })
        ]),
        body: Stack(children: [
          MobileScanner(
              controller: c,
              onDetect: onDetect,
              errorBuilder: (ctx2, err, _) => Center(
                  child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.no_photography_outlined, size: 56, color: Colors.redAccent),
                        SizedBox(height: 12),
                        Text(
                            err.errorCode == MobileScannerErrorCode.permissionDenied
                                ? "Accès à la caméra refusé.\nAutorisez-la : Réglages > Applications > Compte Rendu GBT > Autorisations > Appareil photo."
                                : "Caméra indisponible.\nUtilisez la saisie manuelle.",
                            textAlign: TextAlign.center, style: TextStyle(fontSize: 15)),
                        SizedBox(height: 16),
                        FilledButton(onPressed: () => Navigator.pop(ctx), child: Text('Retour')),
                      ])))),
          Center(child: Container(width: 260, height: 260, decoration: BoxDecoration(border: Border.all(color: col, width: 3), borderRadius: BorderRadius.circular(16)))),
          Positioned(left: 16, right: 16, bottom: 20, child: Column(children: [
            Container(padding: EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(12)), child: Text(msg, textAlign: TextAlign.center, style: TextStyle(color: col, fontSize: 16, fontWeight: FontWeight.bold))),
            SizedBox(height: 10),
            SizedBox(width: double.infinity, child: FilledButton(style: FilledButton.styleFrom(backgroundColor: kGreen), onPressed: () => Navigator.pop(ctx), child: Text('TERMINER'))),
          ])),
        ]),
      );
}

// ───────────── Destinataire WhatsApp ─────────────
class RecipientPage extends StatefulWidget {
  RecipientPage({super.key});
  @override
  State<RecipientPage> createState() => _RecipientPageState();
}

class _RecipientPageState extends State<RecipientPage> {
  String norm(String p) {
    var d = p.replaceAll(RegExp(r'[^\d+]'), '');
    if (d.startsWith('+')) return d.substring(1);
    if (d.startsWith('00')) return d.substring(2);
    if (d.startsWith('0')) return '33${d.substring(1)}'; // indicatif par défaut : France
    return d;
  }
  Future<void> pick() async {
    final ct = await FlutterContacts.openExternalPick();
    if (ct == null) return;
    final full = await FlutterContacts.getContact(ct.id, withProperties: true);
    final ph = (full ?? ct).phones;
    if (ph.isEmpty) return;
    final m = {'name': ct.displayName, 'phone': norm(ph.first.number)};
    Store.addFav(m);
    if (mounted) Navigator.pop(context, m);
  }
  @override
  Widget build(BuildContext c) {
    final favs = Store.favs;
    return Scaffold(
      appBar: AppBar(title: Text('Destinataire')),
      body: ListView(padding: EdgeInsets.all(12), children: [
        FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: kCyan), onPressed: pick, icon: Icon(Icons.contacts), label: Text('Choisir dans les contacts')),
        SizedBox(height: 8),
        OutlinedButton(onPressed: () => Navigator.pop(c, {'name': '', 'phone': ''}), child: Text('Choisir le contact dans WhatsApp')),
        Padding(padding: EdgeInsets.only(top: 18, bottom: 6), child: Text('⭐ Favoris / récents', style: TextStyle(fontSize: 16, color: kCyan))),
        for (final f in favs)
          Card(color: kCard, child: ListTile(
              leading: Icon(Icons.star, color: Colors.amber),
              title: Text(f['name'] ?? ''), subtitle: Text('+${f['phone']}'),
              trailing: IconButton(icon: Icon(Icons.delete_outline), onPressed: () { Store.delFav(f['phone']!); setState(() {}); }),
              onTap: () => Navigator.pop(c, f))),
      ]),
    );
  }
}


// ───────────── Envoi WhatsApp (partagé) ─────────────
Future<void> sendPdf(String path, String phone) async {
  try {
    await _wa.invokeMethod('send', {'path': path, 'phone': phone});
  } catch (_) {
    await Share.shareXFiles([XFile(path)], text: 'Compte Rendu GBT');
  }
}

// ───────────── Signature ─────────────
void paintStrokes(Canvas cv, List<List<Offset>> strokes, double k, Color col) {
  final p = Paint()..color = col..style = PaintingStyle.stroke..strokeWidth = 3 * k..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round;
  for (final s in strokes) {
    if (s.isEmpty) continue;
    if (s.length == 1) { cv.drawCircle(s.first * k, 1.5 * k, Paint()..color = col); continue; }
    final path = Path()..moveTo(s.first.dx * k, s.first.dy * k);
    for (final o in s.skip(1)) { path.lineTo(o.dx * k, o.dy * k); }
    cv.drawPath(path, p);
  }
}

class SigPainter extends CustomPainter {
  final List<List<Offset>> strokes;
  SigPainter(this.strokes);
  @override
  void paint(Canvas c, Size s) => paintStrokes(c, strokes, 1, Colors.black);
  @override
  bool shouldRepaint(SigPainter o) => true;
}

class SignaturePad extends StatefulWidget {
  final String value;
  final ValueChanged<String> onChanged;
  SignaturePad({super.key, required this.value, required this.onChanged});
  @override
  State<SignaturePad> createState() => _SignaturePadState();
}

class _SignaturePadState extends State<SignaturePad> {
  final List<List<Offset>> strokes = [];
  Size area = Size(300, 150);
  bool editing = true;

  @override
  void initState() {
    super.initState();
    editing = widget.value.isEmpty;
  }

  Future<void> save() async {
    if (strokes.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Signez dans le cadre blanc')));
      return;
    }
    final k = 600.0 / area.width;
    final h = area.height * k;
    final rec = ui.PictureRecorder();
    final cv = Canvas(rec);
    cv.drawRect(Rect.fromLTWH(0, 0, 600, h), Paint()..color = Colors.white);
    paintStrokes(cv, strokes, k, Colors.black);
    final img = await rec.endRecording().toImage(600, h.round());
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) return;
    widget.onChanged(base64Encode(data.buffer.asUint8List()));
    if (mounted) setState(() => editing = false);
  }

  @override
  Widget build(BuildContext c) {
    if (!editing && widget.value.isNotEmpty) {
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
            height: 120, width: double.infinity,
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: kLine)),
            child: Image.memory(base64Decode(widget.value), fit: BoxFit.contain)),
        SizedBox(height: 6),
        Row(children: [
          Icon(Icons.check_circle, color: kGreen, size: 18),
          SizedBox(width: 6),
          Text('Signature enregistrée', style: TextStyle(color: kDim, fontSize: 12)),
          Spacer(),
          TextButton.icon(onPressed: () { strokes.clear(); widget.onChanged(''); setState(() => editing = true); }, icon: Icon(Icons.refresh, size: 18), label: Text('Refaire')),
        ]),
      ]);
    }
    return Column(children: [
      ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Container(
              height: 150, width: double.infinity,
              decoration: BoxDecoration(color: Colors.white, border: Border.all(color: kLine), borderRadius: BorderRadius.circular(14)),
              child: LayoutBuilder(builder: (ctx, cs) {
                area = Size(cs.maxWidth, 150);
                return RawGestureDetector(
                    gestures: {EagerGestureRecognizer: GestureRecognizerFactoryWithHandlers<EagerGestureRecognizer>(() => EagerGestureRecognizer(), (EagerGestureRecognizer i) {})},
                    child: Listener(
                        behavior: HitTestBehavior.opaque,
                        onPointerDown: (e) => setState(() => strokes.add([e.localPosition])),
                        onPointerMove: (e) { if (strokes.isNotEmpty) setState(() => strokes.last.add(e.localPosition)); },
                        child: CustomPaint(painter: SigPainter(strokes), size: Size.infinite)));
              }))),
      SizedBox(height: 8),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: () => setState(() => strokes.clear()), icon: Icon(Icons.backspace_outlined), label: Text('Effacer'))),
        SizedBox(width: 10),
        Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: kGreen), onPressed: save, icon: Icon(Icons.check), label: Text('Valider'))),
      ]),
    ]);
  }
}

// ───────────── Historique ─────────────
class HistoryPage extends StatefulWidget {
  HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  Future<void> view(Map<String, dynamic> e) async {
    final f = File(e['file'] as String);
    if (!f.existsSync()) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fichier introuvable')));
      return;
    }
    await Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(
        appBar: AppBar(title: Text('${e['name']}', style: TextStyle(fontSize: 14))),
        body: PdfPreview(build: (_) => f.readAsBytes(), canChangeOrientation: false, canChangePageFormat: false, canDebug: false, allowPrinting: false, allowSharing: false))));
  }

  Future<void> resend(Map<String, dynamic> e) async {
    if (!File(e['file'] as String).existsSync()) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fichier introuvable')));
      return;
    }
    final rec = await Navigator.push<Map<String, String>>(context, MaterialPageRoute(builder: (_) => RecipientPage()));
    if (rec == null) return;
    await sendPdf(e['file'] as String, rec['phone'] ?? '');
  }

  void del(Map<String, dynamic> e) {
    try { File(e['file'] as String).deleteSync(); } catch (_) {}
    Store.delHistory(e['file'] as String);
    setState(() {});
  }

  @override
  Widget build(BuildContext c) {
    final list = Store.history;
    return Scaffold(
      appBar: AppBar(title: Text('Historique')),
      body: list.isEmpty
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.history, size: 52, color: kLine), SizedBox(height: 8), Text('Aucun compte rendu envoyé', style: TextStyle(color: kDim))]))
          : ListView(padding: EdgeInsets.all(14), children: [
              for (final e in list)
                Container(
                    margin: EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(14)),
                    child: ListTile(
                        onTap: () => view(e),
                        leading: HexBadge(size: 40, child: Icon(Icons.description_outlined, size: 18, color: kCyan)),
                        title: Text('${e['patient']} • ${e['act']}', style: TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text('${e['date']} • ${e['surgeon']}\n${e['facility']} • ${e['items']} article(s)', style: TextStyle(fontSize: 12, color: kDim)),
                        isThreeLine: true,
                        trailing: PopupMenuButton<String>(
                            onSelected: (v) { if (v == 'v') { view(e); } else if (v == 'r') { resend(e); } else { del(e); } },
                            itemBuilder: (_) => [
                                  PopupMenuItem(value: 'v', child: Text('Voir le PDF')),
                                  PopupMenuItem(value: 'r', child: Text('Renvoyer via WhatsApp')),
                                  PopupMenuItem(value: 'd', child: Text('Supprimer')),
                                ]))),
            ]),
    );
  }
}

// ───────────── Réglages ─────────────
class SettingsPage extends StatefulWidget {
  SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final keyC = TextEditingController();
  bool showKey = false;

  @override
  void initState() {
    super.initState();
    Store.apiKey.then((k) { if (mounted) setState(() => keyC.text = k); });
  }

  @override
  void dispose() {
    keyC.dispose();
    super.dispose();
  }

  Future<void> pickLogo() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 600);
    if (x == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final dest = '${dir.path}/logo_${DateTime.now().millisecondsSinceEpoch}.png';
    await File(x.path).copy(dest);
    final old = Store.logoPath;
    if (old.isNotEmpty) { try { File(old).deleteSync(); } catch (_) {} }
    Store.setLogo(dest);
    setState(() {});
  }

  @override
  Widget build(BuildContext c) {
    final lp = Store.logoPath;
    return Scaffold(
      appBar: AppBar(title: Text('Réglages')),
      body: ListView(padding: EdgeInsets.all(16), children: [
        sec(Icons.palette_outlined, 'Thème'),
        SegmentedButton<String>(
            segments: [
              ButtonSegment(value: 'dark', label: Text('Sombre'), icon: Icon(Icons.dark_mode_outlined)),
              ButtonSegment(value: 'light', label: Text('Clair'), icon: Icon(Icons.light_mode_outlined)),
              ButtonSegment(value: 'auto', label: Text('Auto'), icon: Icon(Icons.brightness_auto_outlined)),
            ],
            selected: {themeMode.value},
            onSelectionChanged: (s) {
              Store.p.setString('theme', s.first);
              themeMode.value = s.first;
              setState(() {});
            }),
        SizedBox(height: 6),
        Text('Le mode clair est conseillé sous fort éclairage du bloc.', style: TextStyle(fontSize: 12, color: kDim)),
        SizedBox(height: 28),
        sec(Icons.auto_awesome, 'Lecture IA des étiquettes (optionnel)'),
        Text("Avec une clé API Anthropic, la photo est lue par une IA (REF, LOT, date). Sans clé ou hors ligne, la lecture locale est utilisée.", style: TextStyle(fontSize: 12, color: kDim)),
        SizedBox(height: 10),
        TextField(
            controller: keyC, obscureText: !showKey, autocorrect: false, enableSuggestions: false,
            decoration: InputDecoration(
                labelText: 'Clé API (sk-ant-…)', prefixIcon: Icon(Icons.key),
                suffixIcon: IconButton(icon: Icon(showKey ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => showKey = !showKey)))),
        SizedBox(height: 8),
        Row(children: [
          Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: kCyan), onPressed: () async {
            await Store.setApiKey(keyC.text.trim());
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Clé enregistrée')));
          }, icon: Icon(Icons.save_outlined), label: Text('Enregistrer'))),
          SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(onPressed: () async {
            await Store.setApiKey('');
            setState(() => keyC.clear());
          }, icon: Icon(Icons.delete_outline), label: Text('Effacer'))),
        ]),
        SizedBox(height: 6),
        Text("Les photos d'étiquettes ne sont envoyées à Anthropic que si une clé est enregistrée. Évitez d'y photographier des données patient.", style: TextStyle(fontSize: 11, color: kFaint)),
        SizedBox(height: 28),
        sec(Icons.image_outlined, "Logo de l'établissement (en-tête du PDF)"),
        Container(
            height: 90, width: double.infinity,
            decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(14)),
            child: lp.isNotEmpty && File(lp).existsSync()
                ? Padding(padding: EdgeInsets.all(10), child: Image.file(File(lp), fit: BoxFit.contain))
                : Center(child: Text('Aucun logo', style: TextStyle(color: kDim)))),
        SizedBox(height: 10),
        Row(children: [
          Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: kCyan), onPressed: pickLogo, icon: Icon(Icons.upload), label: Text('Choisir'))),
          SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(onPressed: () { final o = Store.logoPath; if (o.isNotEmpty) { try { File(o).deleteSync(); } catch (_) {} } Store.setLogo(''); setState(() {}); }, icon: Icon(Icons.delete_outline), label: Text('Retirer'))),
        ]),
      ]),
    );
  }
}


// ───────────── Lecture d'étiquette par photo (OCR) ─────────────
const kOcrPrompt = r'''Tu es un expert en OCR et en extraction de données médicales/industrielles à partir d'images.

Analyse l'image d'étiquette fournie et extrais de façon exacte les champs suivants :
1. Référence (REF)
2. Numéro de Lot (LOT)
3. Date de péremption (Date limite d'utilisation / Sablier)

--- Directives d'extraction ---
- Sois très vigilant à l'orientation du texte et aux pictogrammes standards (ex. l'icône de sablier pour la date de péremption, "REF" pour la référence, "LOT" pour le lot).
- Si une donnée n'est pas lisible ou absente, indique "Non disponible".
- Renvoie uniquement le résultat sous le format JSON suivant (sans texte d'introduction ni de conclusion) :

{
  "REF": "valeur",
  "LOT": "valeur",
  "Date_de_peremption": "AAAA-MM-JJ"
}''';

const kAiModel = 'claude-sonnet-5-5';
String lastAiText = '';

String _clean(dynamic v) {
  final t = (v ?? '').toString().trim();
  if (t.isEmpty || t.toLowerCase().contains('non disponible')) return '';
  return t;
}

Future<Item?> aiExtract(String path) async {
  final key = await Store.apiKey;
  if (key.isEmpty) return null;
  final bytes = await File(path).readAsBytes();
  final mt = path.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg';
  final res = await http.post(
    Uri.parse('https://api.anthropic.com/v1/messages'),
    headers: {'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json'},
    body: jsonEncode({
      'model': kAiModel,
      'max_tokens': 300,
      'messages': [
        {
          'role': 'user',
          'content': [
            {'type': 'image', 'source': {'type': 'base64', 'media_type': mt, 'data': base64Encode(bytes)}},
            {'type': 'text', 'text': kOcrPrompt},
          ]
        }
      ]
    }),
  ).timeout(Duration(seconds: 45));
  if (res.statusCode == 401) throw Exception('clé API refusée');
  if (res.statusCode != 200) throw Exception('erreur ${res.statusCode}');
  final data = jsonDecode(utf8.decode(res.bodyBytes));
  final txt = (data['content'] as List).where((b) => b['type'] == 'text').map((b) => b['text']).join();
  lastAiText = txt;
  final m = RegExp(r'\{[\s\S]*\}').firstMatch(txt);
  if (m == null) return null;
  final j = jsonDecode(m.group(0)!);
  final exp = _clean(j['Date_de_peremption']);
  final it = Item(ref: _clean(j['REF']), lot: _clean(j['LOT']), exp: normDate(exp) ?? exp);
  if (it.ref.isEmpty && it.lot.isEmpty && it.exp.isEmpty) return null;
  return it;
}

class _Dt {
  final int pos;
  final String iso;
  _Dt(this.pos, this.iso);
}

String _iso(String y, String m, String d) => '$y-${m.padLeft(2, '0')}-${d.padLeft(2, '0')}';
String _eom(String y, String m) => _iso(y, m, '${DateTime(int.parse(y), int.parse(m) + 1, 0).day}');

List<_Dt> findDates(String t) {
  final out = <_Dt>[];
  for (final m in RegExp(r'\b(20\d{2})[-/\. ](0?[1-9]|1[0-2])[-/\. ](0?[1-9]|[12]\d|3[01])\b').allMatches(t)) {
    out.add(_Dt(m.start, _iso(m.group(1)!, m.group(2)!, m.group(3)!)));
  }
  for (final m in RegExp(r'\b(0?[1-9]|[12]\d|3[01])[-/\.](0?[1-9]|1[0-2])[-/\.](20\d{2})\b').allMatches(t)) {
    out.add(_Dt(m.start, _iso(m.group(3)!, m.group(2)!, m.group(1)!)));
  }
  for (final m in RegExp(r'\b(20\d{2})[-/\.](0?[1-9]|1[0-2])\b(?![-/\.]\d)').allMatches(t)) {
    out.add(_Dt(m.start, _eom(m.group(1)!, m.group(2)!)));
  }
  for (final m in RegExp(r'(?<![\d\-/\.])(0?[1-9]|1[0-2])[-/\.](20\d{2})\b').allMatches(t)) {
    out.add(_Dt(m.start, _eom(m.group(2)!, m.group(1)!)));
  }
  return out;
}

String? normDate(String s) {
  final d = findDates(s.toUpperCase());
  return d.isEmpty ? null : d.first.iso;
}

Item parseLabel(String text) {
  final t = text.toUpperCase().replaceAll('\r', '');
  final it = Item(ref: '');
  // GS1 lisible : (01)...(10)...(17)...
  if (RegExp(r'\(\s*(01|10|17)\s*\)').hasMatch(t)) {
    for (final m in RegExp(r'\(\s*(\d{2,4})\s*\)\s*([A-Z0-9\-\./]+)').allMatches(t)) {
      final ai = m.group(1)!, v = m.group(2)!;
      if (ai == '01' && it.ref.isEmpty) it.ref = v;
      if (ai == '10' && it.lot.isEmpty) it.lot = v;
      if (ai == '17' && v.length >= 6 && it.exp.isEmpty) {
        final dd = v.substring(4, 6) == '00' ? '28' : v.substring(4, 6);
        it.exp = '20${v.substring(0, 2)}-${v.substring(2, 4)}-$dd';
      }
    }
  }
  final banned = {'REF', 'LOT', 'EXP', 'SN', 'QTY', 'QTE', 'NO', 'STERILE', 'STERILE'};
  String? pick(RegExp re) {
    for (final m in re.allMatches(t)) {
      final v = m.group(1)!.replaceAll(RegExp(r'[\.\-/]+$'), '');
      if (v.length >= 2 && !banned.contains(v)) return v;
    }
    return null;
  }
  if (it.ref.isEmpty) {
    it.ref = pick(RegExp(r'\b(?:REF|RÉF|REFERENCE|RÉFÉRENCE|CAT\.?(?:\s*(?:NO|N°))?)\b\s*[:.#]?\s*([A-Z0-9][A-Z0-9\-\./]*)')) ??
        RegExp(r'\b(\d{13,14})\b').firstMatch(t)?.group(1) ??
        '';
  }
  if (it.lot.isEmpty) {
    it.lot = pick(RegExp(r'\b(?:LOT|BATCH|CHARGE|LOTE)\b\s*(?:NO|N°|NUMBER|#)?\s*[:.#]?\s*([A-Z0-9][A-Z0-9\-\./]*)')) ?? '';
  }
  if (it.exp.isEmpty) {
    final ds = findDates(t);
    if (ds.isNotEmpty) {
      final kws = RegExp(r'EXP|PÉREMP|PEREMP|USE BY|UTILISER AVANT|⌛|VERFALL').allMatches(t).map((m) => m.end).toList();
      _Dt? best;
      var bd = 1 << 30;
      for (final d in ds) {
        for (final k in kws) {
          final dist = (d.pos - k).abs();
          if (dist < bd && dist < 60) { bd = dist; best = d; }
        }
      }
      final chosen = best ?? ds.reduce((a, b) => a.iso.compareTo(b.iso) >= 0 ? a : b);
      it.exp = chosen.iso;
    }
  }
  return it;
}

class PhotoResultPage extends StatefulWidget {
  final String path;
  PhotoResultPage({super.key, required this.path});
  @override
  State<PhotoResultPage> createState() => _PhotoResultPageState();
}

class _PhotoResultPageState extends State<PhotoResultPage> {
  late String path;
  final refC = TextEditingController(), lotC = TextEditingController(), expC = TextEditingController();
  String raw = '';
  bool busy = true;
  String? err;

  @override
  void initState() {
    super.initState();
    path = widget.path;
    run();
  }

  @override
  void dispose() {
    refC.dispose();
    lotC.dispose();
    expC.dispose();
    super.dispose();
  }

  String source = '';

  Future<void> run() async {
    setState(() { busy = true; err = null; source = ''; });
    Item? it;
    try {
      it = await aiExtract(path);
      if (it != null) { source = 'Lecture IA'; raw = lastAiText; }
    } catch (e) {
      err = 'IA indisponible (${e.toString().replaceFirst('Exception: ', '')}) : lecture locale utilisée.';
    }
    if (it == null) {
      final rec = mlk.TextRecognizer(script: mlk.TextRecognitionScript.latin);
      try {
        final out = await rec.processImage(mlk.InputImage.fromFilePath(path));
        raw = out.text;
        it = parseLabel(raw);
        source = 'Lecture locale';
      } catch (e) {
        err = 'Lecture automatique impossible : saisissez les champs à la main.';
      } finally {
        await rec.close();
      }
    }
    if (it != null) {
      refC.text = it.ref;
      lotC.text = it.lot;
      expC.text = it.exp;
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> retake() async {
    final x = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 90, maxWidth: 2200);
    if (x == null) return;
    setState(() => path = x.path);
    await run();
  }

  void confirm() {
    if (refC.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('La référence est obligatoire')));
      return;
    }
    final exp = normDate(expC.text) ?? expC.text.trim();
    Navigator.pop(context, Item(ref: refC.text.trim(), lot: lotC.text.trim(), exp: exp));
  }

  Widget field(String label, TextEditingController c, String hint, IconData icon) {
    final ok = c.text.trim().isNotEmpty;
    return Padding(
        padding: EdgeInsets.only(bottom: 12),
        child: TextField(
            controller: c,
            onChanged: (_) => setState(() {}),
            textCapitalization: TextCapitalization.characters,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            decoration: InputDecoration(
                labelText: label,
                hintText: hint,
                prefixIcon: Icon(icon, color: kCyan),
                suffixIcon: busy ? null : Icon(ok ? Icons.check_circle : Icons.error_outline, color: ok ? kGreen : Colors.orange),
                helperText: busy ? null : (ok ? null : 'Non détecté : saisissez-le ou reprenez la photo'))));
  }

  @override
  Widget build(BuildContext c) {
    final expIso = normDate(expC.text) ?? expC.text.trim();
    final expired = Item(ref: '', exp: expIso).expired;
    return Scaffold(
      appBar: AppBar(title: Text("Vérifier l'étiquette")),
      body: Column(children: [
        Expanded(
            child: ListView(padding: EdgeInsets.all(16), children: [
          InkWell(
              onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => Scaffold(
                  backgroundColor: Colors.black,
                  appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
                  body: InteractiveViewer(maxScale: 6, child: Center(child: Image.file(File(path))))))),
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                      height: 210, color: Colors.black,
                      child: Stack(fit: StackFit.expand, children: [
                        Image.file(File(path), fit: BoxFit.contain),
                        Positioned(right: 8, bottom: 8, child: Container(padding: EdgeInsets.all(6), decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)), child: Icon(Icons.zoom_in, color: Colors.white))),
                      ])))),
          SizedBox(height: 12),
          if (busy) ...[LinearProgressIndicator(), SizedBox(height: 6), Text('Lecture de la photo…', style: TextStyle(color: kDim, fontSize: 12)), SizedBox(height: 10)],
          if (!busy && source.isNotEmpty) Padding(padding: EdgeInsets.only(bottom: 10), child: Row(children: [Icon(source == 'Lecture IA' ? Icons.auto_awesome : Icons.text_fields, size: 16, color: kCyan), SizedBox(width: 6), Text('$source : vérifiez avant d\'ajouter', style: TextStyle(fontSize: 12, color: kDim))])),
          if (err != null) Padding(padding: EdgeInsets.only(bottom: 10), child: Text(err!, style: TextStyle(color: Colors.orange))),
          if (expired) Container(margin: EdgeInsets.only(bottom: 12), padding: EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.redAccent.withOpacity(0.15), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.redAccent)), child: Row(children: [Icon(Icons.warning_amber, color: Colors.redAccent), SizedBox(width: 8), Expanded(child: Text('Produit PÉRIMÉ : vérifiez la date', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)))])),
          field('Réf :', refC, 'ex. 6541-3-102', Icons.tag),
          field('Lot :', lotC, 'ex. L2409871', Icons.inventory_2_outlined),
          field('Date de péremption :', expC, 'AAAA-MM-JJ', Icons.event_busy_outlined),
          ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: Text('Texte détecté sur la photo', style: TextStyle(fontSize: 13, color: kDim)),
              children: [Align(alignment: Alignment.centerLeft, child: SelectableText(raw.isEmpty ? '—' : raw, style: TextStyle(fontSize: 12, color: kDim)))]),
          SizedBox(height: 6),
          Text('Astuce : cadrez bien l\'étiquette, évitez les reflets et approchez-vous.', style: TextStyle(fontSize: 11, color: kFaint)),
        ])),
        Container(
            decoration: BoxDecoration(color: kBar, border: Border(top: BorderSide(color: kLine))),
            padding: EdgeInsets.fromLTRB(12, 10, 12, 10),
            child: SafeArea(
                top: false,
                child: Row(children: [
                  Expanded(child: OutlinedButton.icon(onPressed: busy ? null : retake, icon: Icon(Icons.photo_camera_outlined), label: Text('Reprendre'))),
                  SizedBox(width: 10),
                  Expanded(flex: 2, child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: kGreen), onPressed: busy ? null : confirm, icon: Icon(Icons.check), label: Text("Ajouter l'article"))),
                ]))),
      ]),
    );
  }
}
